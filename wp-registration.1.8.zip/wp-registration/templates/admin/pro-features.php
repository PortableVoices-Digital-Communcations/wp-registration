<?php
/**
 * pro features
 */
 ?>
 
 <h3>Upgrade to Pro version for Following Features</h3>
<ol>
<li>Simplest Registration Form Designer</li>
<li>Login &amp; Signup with Facebook</li>
<li>Member Directory
<ol>
<li>List View</li>
<li>Grid View</li>
</ol>
</li>
<li>Edit Profile
<ol>
<li>Change Password</li>
</ol>
</li>
<li>Email Templates</li>
<li>Set Redirects (after login and registration)</li>
<li>Change Form Design
<ol>
<li>Color</li>
<li>Labels</li>
<li>CSS Editor</li>
</ol>
</li>
<li>Avartar</li>
</ol>

<a href="http://najeebmedia.com/wordpress-plugin/wp-user-registration-form/" title="WP User Registration Form PRO">Click for More detail</a>
