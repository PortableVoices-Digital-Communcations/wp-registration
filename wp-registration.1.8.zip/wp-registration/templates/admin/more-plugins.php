 <?php 
global $nm_wpregistration;
?>
 <link rel="stylesheet" type="text/css" href="<?php echo $nm_wpregistration->plugin_meta['url']?>/css/grid/simplegrid.css" />
<style>
  .content:hover{
   
        //padding: 7px;
    box-shadow: 0px 0px 16px 0px;

    z-index: 99;
    //color: #007eb1;
    border: 1px solid #d8d8d8;
    border-radius: 4%;
  }
</style>
<div class="grid grid-pad">
    <div class="col-1-3">
      <a style="text-decoration: none;" href="http://najeebmedia.com/wordpress-plugin/wp-front-end-file-upload-and-download-manager/" title="WORDPRESS FRONT-END FILE MANAGER" target="_new">
       <div class="content" style="text-align: center;">
           <img width="80" style="display: block;margin: 0 auto;" height="80" src="http://i1.wp.com/najeebmedia.com/wp-content/uploads/2015/12/nm-fileuploader.png?fit=80%2C80" class="vc_single_image-img attachment-full" alt="nm-message"><h2>WORDPRESS FRONT-END FILE MANAGER</h2>
<p>This plugin renders an upload form on front-end for users to upload and manage their files and even create directories. This plugins can be use for purposes like images, files and media manager for students or staff. It has much much feature in it. Please explore with following button.</p>
       </div>
        </a>
    </div>
  
  	<div class="col-1-3">
      <a style="text-decoration: none;" href="http://najeebmedia.com/wordpress-plugin/wordpress-mailchimp-subscription-form-create-manage-campaigns/" title="WORDPRESS FRONT-END FILE MANAGER" target="_new">
       <div class="content" style="text-align: center;">
           <img width="80" style="display: block;margin: 0 auto;" height="80" src="http://i2.wp.com/najeebmedia.com/wp-content/uploads/2015/12/nm-message.png?fit=80%2C80" class="vc_single_image-img attachment-full" alt="nm-message"><h2>MAILCHIMP CAMPAIGN MANAGER</h2>
<p>Create Mailchimp Newsletters with WordPress Posts and Pages and track with graphical reports from Dashboard. Even create subscription forms with visual form designer. Create merge vars and interests.All in one solution for you marketing.</p>
       </div>
        </a>
    </div>
  
    <div class="col-1-3">
      	<a style="text-decoration: none;" href="http://najeebmedia.com/wordpress-plugin/wp-contact-form-file-upload/" 		title="CONTACT FORM" target="_new">
       <div class="content" style="text-align: center;">
           <img width="80" style="display: block;margin: 0 auto;" height="80" src="http://i2.wp.com/najeebmedia.com/wp-content/uploads/2015/12/nm-contactform.png?fit=80%2C80" class="vc_single_image-img attachment-full" alt="nm-message"><h2>CONTACT FORM</h2>
<p>We know Gravity Forms, Contact Form 7 exists. But this plugin renders fields with Awesome File upload control. A very handy solution to receive files/images from users with secure file upload script.</p>
       </div>
        </a>
    </div>
</div>
<div class="grid grid-pad">
  <div class="col-1-3">
    <a style="text-decoration: none;" href="http://najeebmedia.com/wordpress-plugin/wordpress-front-end-member-private-message-with-file-attachment/" title="MESSAGING BETWEEN MEMBERS" target="_new">
 <div class="content" style="text-align: center;">
           <img width="80" style="display: block;margin: 0 auto;" height="80" src="http://i1.wp.com/najeebmedia.com/wp-content/uploads/2015/12/nm-user.png?fit=80%2C80" class="vc_single_image-img attachment-full" alt="nm-message"><h2>MESSAGING BETWEEN MEMBERS</h2>
<p>Members can send messages with files/images attached to each other. Again it&rsquo;s very simple and light plugin to setup. This plugin renders a form with &lsquo;Inbox &amp; Compose&rsquo; message tabs. Email notification is sent each time a message is sent to members.</p>
       </div>
        </a>
     </div>
      <div class="col-1-3">
        <a style="text-decoration: none;" href="http://najeebmedia.com/wordpress-plugin/wordpress-live-currency-exchange-rate-ticker/" title="LIVE CURRENCY TICKER" target="_new">
       <div class="content" style="text-align: center;">
          <img width="80" style="display: block;margin: 0 auto;" height="80" src="http://i2.wp.com/najeebmedia.com/wp-content/uploads/2015/12/nm-liverticker.png?fit=80%2C80" class="vc_single_image-img attachment-full" alt="nm-message"><h2>LIVE CURRENCY TICKER</h2>
<p>This plugin display a top Bar as Ticker that fetches Live Currency Rates of selected countries and display its exchange rate against USD. Admin set interval for each fetch to show fresh rates with nice animations on top menu.</p>
       </div>
      </a>
    </div>
</div>